import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Configuration;
import static com.codeborne.selenide.Selenide.*;
import org.junit.Test;

public class Lab {
    @Test
    public void ZakazComment()
    {
        //Test1(Открытие сайта)
        Configuration.holdBrowserOpen = true;
        open("https://cheekychicken.ru/");
    }
    @Test
    public void ChickenINBasket() {
        //Test2(Проверка акции)
        $x("//a[@href='/actions']").click();
        sleep(500);
        $x("//a[@href='/#krylya']").click();
        sleep(500);
    }
    @Test
    public void KomboINBasket() {
        //Test3(Проверка кнопки острое)
        $x("//div [@data-type = 'hot']").click();
        sleep(500);
        $x("//div [@data-type = 'hot']").click();
        sleep(500);
    }
    @Test
    public void FilleINBasket() {
        //Test4(Проверка кнопки акции)
        $x("//div [@data-type = 'action']").click();
        sleep(500);
        $x("//div [@data-type = 'action']").click();
        sleep(500);
    }
    @Test
    public void DrinkINBasket() {
        //Test5(Проверка кнопки Хит)
        $x("//div [@data-type = 'hit']").click();
        sleep(500);
        $x("//div [@data-type = 'hit']").click();
        sleep(500);
    }
    @Test
    public void Hit() {
        //Test6((Проверка кнопки новое)
        $x("//div [@data-type = 'new']").click();
        sleep(500);
        $x("//div [@data-type = 'new']").click();
        sleep(500);
    }
    @Test
    public void Hot() {
        //Test7(Курочка в корзину)
        $x("//button [@data-id = '4']").click();
        sleep(1000);
    }
    @Test
    public void New() {
        //Test8(Филе в корзину)
        $x("//a[@href='/#file']").click();
        $x("//button [@data-id = '27']").click();
        sleep(1000);
    }
    @Test
    public void Open() {
        //Test9(Закуски в корзину)
        $x("//a[@href='/#zakuski']").click();
        $x("//button [@data-id = '10']").click();
        sleep(1000);
    }
    @Test
    public void Zakaz() {
        //Test10(Комбо в корзину)
        $x("//a[@href='/#kombo']").click();
        $x("//button [@data-id = '17']").click();
        sleep(1000);
    }
    @Test
    public void ZakazOplataNal() {
        //Test11(Напитки в корзину)
        $x("//a[@href='/#napitki']").click();
        $x("//button [@data-id = '45']").click();
        sleep(1000);
    }
    @Test
    public void ZakazAddress() {
        //Test12(Переход в корзину)
        $x("//a [@class='chiken-btn chiken-btn--1']").click();
        sleep(1000);
    }
    @Test
    public void ZakazPromocode() {
        //Test13(Оформить заказ)
        $x("//button [@class='chiken-btn chiken-btn--1']").click();
        sleep(500);
    }
    @Test
    public void ZakazScrollUP() {
        //Test14(Ввести имя)
        $x("//input[@name='name']").setValue("Павел");
        sleep(500);
    }
    @Test
    public void ZakazName() {
        //Test15(Ввести адрес)
        $x("//input[@name='phone']").setValue("9829173828");
        sleep(500);
    }
    @Test
    public void ZakazEmail() {
        //Test16(Ввести почту)
        $x("//input[@name='email']").setValue("hello@gmail.com");
        sleep(500);
    }
    @Test
    public void ZakazPhone() {
        //$x("//input[@name='address']").setValue("г Иркутск, ул Пушкина, д 1");
        $x("//input[@name='house']").setValue("1");
        $x("//input[@name='front_door']").setValue("1");
        $x("//input[@name='floor']").setValue("1");
        $x("//input[@name='intercom']").setValue("1");
        sleep(500);
    }
    @Test
    public void ZakuskiINBasket() {
        //Test18(Выбор способа оплаты)
        $x("//button [@data-id = '2']").click();
        sleep(500);
    }
    @Test
    public void SalesOpen() {
        //Test19(Комментарий к заказу)
        $x("//textarea[@name='comment']").setValue("Спасибо за доставку");
        sleep(500);
    }
    @Test
    public void Action() {
        //Test20(Промокд)
        $x("//input[@name='promocode']").setValue("Зима2024");
        $x("//button [@class='chiken-btn chiken-btn--1 js-cart-promocode-apply _show']").click();
        sleep(500);
    }
    @Test
    public void Basket() {
        //Test21(Вернуться вверх корзины)
        $x("//button [@class='cart-form__scroll-top']").click();
        sleep(500);
    }
    //Лаб 6
    //@Test
    //public void TestName(){
        //Configuration.holdBrowserOpen = true;
        //open("https://www.google.ru/webhp?hl=ru");
        //$x("//textarea[@name='q']").setValue("Вокин Павел").pressEnter();
    //}
}


